#pragma once

enum class BuildingType
{
	residential,
	institution,
	production
};